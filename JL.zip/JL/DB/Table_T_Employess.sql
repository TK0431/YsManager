﻿USE JLDB;

DROP TABLE IF EXISTS T_Employess;

CREATE TABLE T_Employess(
    Eid varchar(10) PRIMARY KEY NOT NULL COMMENT 'ID',
    Epass varchar(10) NOT NULL COMMENT '密码',
    Elevel int NOT NULL COMMENT '权限',
    Ename varchar(20) NOT NULL COMMENT '姓名',
    Ephone varchar(14) NULL COMMENT '电话',
    Eaddress varchar(50) NULL COMMENT '地址',
    Eprices decimal(3,2) NULL COMMENT '提成',
    Esalary decimal(9,2) NULL COMMENT '底薪',
    SHid varchar(10) NULL COMMENT '店铺',
    Enote varchar(50) NULL COMMENT '备注'
);

INSERT INTO T_Employess VALUES ('S000','12345',9,'超级用户','0',null,0,0,'',null);
INSERT INTO T_Employess VALUES ('S001','12341',1,'测试1','110','地址1',0.01,10,'001','备注1');
INSERT INTO T_Employess VALUES ('S002','12342',2,'测试2','120','地址2',0.99,99999,'002',null);
INSERT INTO T_Employess VALUES ('S003','12343',3,'测试3','0512-152863','地址3',1.0,9000,'003',null);
INSERT INTO T_Employess VALUES ('S004','12344',4,'测试4','999','地址4',0,8000,'004',null);