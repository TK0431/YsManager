USE JLDB;

DROP TABLE IF EXISTS T_Order;

CREATE TABLE T_Order(
    OrderId varchar(10) PRIMARY KEY NOT NULL,
    OrderType int NOT NULL,
    OrderTime datetime NOT NULL,
    OrderGoods varchar(50) NULL,
    OrderNum decimal(10,2) NULL,
    OrderPrice decimal(10,2) NULL,
    OrderBack nvarchar(50) NULL,
    OrderUser nvarchar(10) NOT NULL
);

INSERT INTO T_Order VALUES ('OD001',1,'2019/01/01','阿迪1',201,23501,'今日发货1','蒋');
INSERT INTO T_Order VALUES ('OD002',2,'2019/02/01','阿迪2',202,23502,'今日发货2','蒋');
INSERT INTO T_Order VALUES ('OD003',3,'2019/03/01','阿迪3',203,23503,'今日发货3','蒋');
INSERT INTO T_Order VALUES ('OD004',4,'2019/04/01','阿迪4',204,23504,'今日发货4','蒋');
INSERT INTO T_Order VALUES ('OD005',1,'2019/05/01','阿迪5',205,23505,'今日发货5','蒋');
INSERT INTO T_Order VALUES ('OD006',2,'2019/06/01','阿迪6',206,23506,'今日发货6','蒋');
INSERT INTO T_Order VALUES ('OD007',3,'2019/07/01','阿迪7',207,23507,'今日发货7','蒋');
INSERT INTO T_Order VALUES ('OD008',4,'2019/08/01','阿迪8',208,23508,'今日发货8','蒋');
INSERT INTO T_Order VALUES ('OD009',1,'2019/10/01','阿迪9',209,23509,'今日发货9','蒋');
INSERT INTO T_Order VALUES ('OD010',2,'2019/11/01','阿迪10',210,23510,'今日发货10','蒋');