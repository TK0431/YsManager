USE JLDB;

DROP TABLE IF EXISTS T_User;

CREATE TABLE T_User(
    UserId varchar(10) PRIMARY KEY NOT NULL,
    UserName varchar(20) NOT NULL,
    UserSex nchar(1) NOT NULL,
    UserPhone varchar(13) NULL,
    UserAddress varchar(50) NULL,
    UserPrice decimal(10,2) NULL,
    UserSalary decimal(10,2) NULL,
    UserPass varchar(20) NOT NULL,
    UserLevel int NOT NULL
);

INSERT INTO T_User VALUES ('ID000','supper','M',null,null,null,null,'12345',99);