﻿using System.Windows.Controls;

namespace JL
{
    /// <summary>
    /// PageMenu.xaml 的交互逻辑
    /// </summary>
    public partial class PageMenu : Page
    {
        public PageMenu()
        {
            InitializeComponent();
            this.DataContext = new PageMenuViewModel();
        }
    }
}
