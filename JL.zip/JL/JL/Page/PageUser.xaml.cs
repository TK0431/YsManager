﻿using System.Windows.Controls;

namespace JL
{
    /// <summary>
    /// PageEmployess.xaml 的交互逻辑
    /// </summary>
    public partial class PageUser : Page
    {
        public PageUser()
        {
            InitializeComponent();

            this.DataContext = new PageEmployessViewModel(this);
        }
    }
}
