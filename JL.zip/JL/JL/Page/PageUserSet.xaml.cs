﻿using System.Windows.Controls;

namespace JL
{
    /// <summary>
    /// PageEmployessSet.xaml 的交互逻辑
    /// </summary>
    public partial class PageUserSet : Page
    {
        public PageUserSet(PageEmployessViewModel model)
        {
            InitializeComponent();

            this.DataContext = new PageEmployessSetViewModel(this, model);
        }
    }
}
