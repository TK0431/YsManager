﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace JL
{
    public static class DBPageShellStock
    {
        public static MySqlDataReader GetListInfo(DBManagerMySql db, PageShellStockViewModel model)
        {
            db.AppendLine("SELECT");
            db.AppendLine("    OrderId,");
            db.AppendLine("    OrderType,");
            db.AppendLine("    OrderTime,");
            db.AppendLine("    OrderGoods,");
            db.AppendLine("    OrderNum,");
            db.AppendLine("    OrderPrice,");
            db.AppendLine("    OrderBack,");
            db.AppendLine("    OrderUser");
            db.AppendLine("FROM T_Order");
            db.AppendLine("WHERE 1=1");

            if (string.IsNullOrEmpty(model.DateFrom.ToString()))
            {
                db.AppendLine("  AND OrderTime >= @DateFrom");
                db.AddParameter("@DateFrom", model.DateFrom, MySqlDbType.DateTime);
            }
            if (string.IsNullOrEmpty(model.DateTo.ToString()))
            {
                db.AppendLine("  AND OrderTime <= @OrderTime");
                db.AddParameter("@OrderTime", model.DateFrom, MySqlDbType.DateTime);
            }

            return db.ExecuteReader();
        }
    }
}