﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace JL
{
    public class DBManager : IDisposable
    {
        /// <summary>
        /// SQL文
        /// </summary>
        private StringBuilder Sql = new StringBuilder();

        // 数据库参数结构
        private struct Parameter
        {
            public String Key;
            public object Value;
            public SqlDbType Type;
        }

        /// <summary>
        /// 连接数据库用
        /// </summary>
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        SqlCommand com;

        /// <summary>
        /// SQL参数List
        /// </summary>
        List<Parameter> ParametersList = new List<Parameter>();

        public DBManager()
        {
            // 连接数据库
            con.Open();
            com = con.CreateCommand();
        }

        /// <summary>
        /// 添加SQL文
        /// </summary>
        /// <param name="line"></param>
        public void AppendLine(string line)
        {
            Sql.AppendLine(line);
        }

        /// <summary>
        /// 追加参数
        /// </summary>
        /// <param name="key">参数</param>
        /// <param name="value">值</param>
        /// <param name="type">类型</param>
        public void AddParameter(string key, object value, SqlDbType type)
        {
            Parameter param = new Parameter() {
                Key = key,
                Value = value ?? DBNull.Value,
                Type = type
            };

            ParametersList.Add(param);
        }

        /// <summary>
        /// 检索用
        /// </summary>
        /// <returns></returns>
        public SqlDataReader ExecuteReader()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            SqlDataReader sdr = com.ExecuteReader();
            ClearParameters();
            return sdr;
        }

        /// <summary>
        /// 更新删除用
        /// </summary>
        /// <returns></returns>
        public int ExecuteNonQuery()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            int result = com.ExecuteNonQuery();
            ClearParameters();
            return result;
        }

        /// <summary>
        /// 简单检索用
        /// </summary>
        /// <returns></returns>
        public object ExecuteScalar()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            object result = com.ExecuteScalar();
            ClearParameters();
            return result;
        }

        /// <summary>
        /// 添加SQL参数
        /// </summary>
        private void AddParameters()
        {
            foreach (Parameter param in ParametersList)
            {
                com.Parameters.Add(param.Key, param.Type);
                com.Parameters[param.Key].Value = param.Value;
            }
        }

        /// <summary>
        /// 清空SQL参数
        /// </summary>
        private void ClearParameters()
        {
            com.Parameters.Clear();
            ParametersList.Clear();
            Sql.Clear();
        }

        /// <summary>
        /// 断开数据库
        /// </summary>
        public void Dispose()
        {
            con.Close();
        }
    }
}
