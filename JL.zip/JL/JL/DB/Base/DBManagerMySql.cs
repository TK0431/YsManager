﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using MySql.Data.MySqlClient;

namespace JL
{
    public class DBManagerMySql:IDisposable
    {
        /// <summary>
        /// SQL文
        /// </summary>
        private StringBuilder Sql = new StringBuilder();

        // 数据库参数结构
        private struct Parameter
        {
            public String Key;
            public object Value;
            public MySqlDbType Type;
        }

        /// <summary>
        /// 连接数据库用
        /// </summary>
        MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["ConnectionMysqlString"].ToString());
        MySqlCommand com;

        /// <summary>
        /// SQL参数List
        /// </summary>
        List<Parameter> ParametersList = new List<Parameter>();

        public DBManagerMySql()
        {
            // 连接数据库
            con.Open();
            com = con.CreateCommand();
        }

        /// <summary>
        /// 添加SQL文
        /// </summary>
        /// <param name="line"></param>
        public void AppendLine(string line)
        {
            Sql.AppendLine(line);
        }

        /// <summary>
        /// 追加参数
        /// </summary>
        /// <param name="key">参数</param>
        /// <param name="value">值</param>
        /// <param name="type">类型</param>
        public void AddParameter(string key, object value, MySqlDbType type)
        {
            Parameter param = new Parameter()
            {
                Key = key,
                Value = value ??  DBNull.Value,
                Type = type
            };

            ParametersList.Add(param);
        }

        /// <summary>
        /// 检索用
        /// </summary>
        /// <returns></returns>
        public MySqlDataReader ExecuteReader()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            MySqlDataReader sdr = com.ExecuteReader();
            ClearParameters();
            return sdr;
        }

        /// <summary>
        /// 更新删除用
        /// </summary>
        /// <returns></returns>
        public int ExecuteNonQuery()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            int result = com.ExecuteNonQuery();
            ClearParameters();
            return result;
        }

        /// <summary>
        /// 简单检索用
        /// </summary>
        /// <returns></returns>
        public object ExecuteScalar()
        {
            com.CommandText = Sql.ToString();

            AddParameters();

            object result = com.ExecuteScalar();
            ClearParameters();
            return result;
        }

        /// <summary>
        /// 添加SQL参数
        /// </summary>
        private void AddParameters()
        {
            foreach (Parameter param in ParametersList)
            {
                com.Parameters.Add(param.Key, param.Type);
                com.Parameters[param.Key].Value = param.Value;
            }
        }

        /// <summary>
        /// 清空SQL参数
        /// </summary>
        private void ClearParameters()
        {
            com.Parameters.Clear();
            ParametersList.Clear();
            Sql.Clear();
        }

        /// <summary>
        /// 断开数据库
        /// </summary>
        public void Dispose()
        {
            con.Close();
        }
    }

    /// <summary>
    /// Mysql数据转换
    /// </summary>
    public static class DBDataMySql
    {
        /// <summary>
        /// String
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string TOString(object obj)
        {
            return obj.ToString();
        }

        /// <summary>
        /// Decimal
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static decimal TODecimal(object obj)
        {
            if (decimal.TryParse(obj.ToString(), out decimal data))
            {
                return data;
            }
            else { return 0; }
        }

        /// <summary>
        /// int
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static int TOInt(object obj)
        {
            if (int.TryParse(obj.ToString(), out int data))
            {
                return data;
            }
            else { return 0; }
        }

        /// <summary>
        /// DateTime
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static DateTime TODateTime(object obj)
        {
            if (DateTime.TryParse(obj.ToString(), out DateTime data))
            {
                return data;
            }
            else { return DateTime.Parse("1900/01/01"); }
        }

        /// <summary>
        /// Enum
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static object TOEnum(object obj,Type type)
        {
            return Enum.ToObject(type, TOInt(obj));
        }
    }
}
