﻿using MySql.Data.MySqlClient;

namespace JL
{
    public static class DBPageUserSet
    {
        /// <summary>
        /// 登录新员工
        /// </summary>
        /// <param name="db"></param>
        /// <param name="model"></param>
        public static int AddEmployess(DBManagerMySql db, PageEmployessSetViewModel model)
        {
            db.AppendLine(@"INSERT INTO T_Employess");
            db.AppendLine(@"  (");
            db.AppendLine(@"    Eid ,");
            db.AppendLine(@"    Epass,");
            db.AppendLine(@"    Elevel,");
            db.AppendLine(@"    Ename,");
            db.AppendLine(@"    Ephone,");
            db.AppendLine(@"    Eaddress,");
            db.AppendLine(@"    Eprices,");
            db.AppendLine(@"    Esalary,");
            db.AppendLine(@"    SHid,");
            db.AppendLine(@"    Enote");
            db.AppendLine(@"  ) VALUES (");
            db.AppendLine(@"    @Eid ,");
            db.AppendLine(@"    @Epass,");
            db.AppendLine(@"    @Elevel,");
            db.AppendLine(@"    @Ename,");
            db.AppendLine(@"    @Ephone,");
            db.AppendLine(@"    @Eaddress,");
            db.AppendLine(@"    @Eprices,");
            db.AppendLine(@"    @Esalary,");
            db.AppendLine(@"    @SHid,");
            db.AppendLine(@"    @Enote");
            db.AppendLine(@"  )");

            db.AddParameter("Eid", model.Eid, MySqlDbType.VarChar);
            db.AddParameter("Epass", model.Epass, MySqlDbType.VarChar);
            db.AddParameter("Elevel", model.Elevel, MySqlDbType.Int32);
            db.AddParameter("Ename", model.Ename, MySqlDbType.VarChar);
            db.AddParameter("Ephone", model.Ephone, MySqlDbType.VarChar);
            db.AddParameter("Eaddress", model.Eaddress, MySqlDbType.VarChar);
            db.AddParameter("Eprices", model.Eprices, MySqlDbType.Decimal);
            db.AddParameter("Esalary", model.Esalary, MySqlDbType.Decimal);
            db.AddParameter("SHid", model.SHid, MySqlDbType.VarChar);
            db.AddParameter("Enote", model.Enote, MySqlDbType.VarChar);

            return db.ExecuteNonQuery();
        }

        /// <summary>
        /// 更新员工
        /// </summary>
        /// <param name="db"></param>
        /// <param name="model"></param>
        public static int UpdEmployess(DBManagerMySql db, PageEmployessSetViewModel model)
        {
            db.AppendLine(@"UPDATE T_Employess ");
            db.AppendLine(@"  SET ");
            db.AppendLine(@"      Epass = @Epass,");
            db.AppendLine(@"      Elevel = @Elevel,");
            db.AppendLine(@"      Ename = @Ename,");
            db.AppendLine(@"      Ephone = @Ephone,");
            db.AppendLine(@"      Eaddress = @Eaddress,");
            db.AppendLine(@"      Eprices = @Eprices,");
            db.AppendLine(@"      Esalary = @Esalary,");
            db.AppendLine(@"      SHid = @SHid,");
            db.AppendLine(@"      Enote = @Enote");
            db.AppendLine(@"WHERE");
            db.AppendLine(@"    Eid = @Eid");

            db.AddParameter("Eid", model.Eid, MySqlDbType.VarChar);
            db.AddParameter("Epass", model.Epass, MySqlDbType.VarChar);
            db.AddParameter("Elevel", model.Elevel, MySqlDbType.Int32);
            db.AddParameter("Ename", model.Ename, MySqlDbType.VarChar);
            db.AddParameter("Ephone", model.Ephone, MySqlDbType.VarChar);
            db.AddParameter("Eaddress", model.Eaddress, MySqlDbType.VarChar);
            db.AddParameter("Eprices", model.Eprices, MySqlDbType.Decimal);
            db.AddParameter("Esalary", model.Esalary, MySqlDbType.Decimal);
            db.AddParameter("SHid", model.SHid, MySqlDbType.VarChar);
            db.AddParameter("Enote", model.Enote, MySqlDbType.VarChar);

            return db.ExecuteNonQuery();
        }
    }
}
