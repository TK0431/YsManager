﻿using MySql.Data.MySqlClient;

namespace JL
{
    public class DBPageUser
    {
        /// <summary>
        /// 用户查询
        /// </summary>
        /// <param name="db"></param>
        /// <param name="model"></param>
        public static MySqlDataReader SearchUser(DBManagerMySql db, PageEmployessViewModel model)
        {
            db.AppendLine(@"SELECT");
            db.AppendLine(@"  Eid,");
            db.AppendLine(@"  Epass,");
            db.AppendLine(@"  Elevel,");
            db.AppendLine(@"  Ename,");
            db.AppendLine(@"  Ephone,");
            db.AppendLine(@"  Eaddress,");
            db.AppendLine(@"  Eprices,");
            db.AppendLine(@"  Esalary,");
            db.AppendLine(@"  SHid,");
            db.AppendLine(@"  Enote");
            db.AppendLine(@"FROM T_Employess");
            db.AppendLine(@"WHERE");
            db.AppendLine(@"  Eid LIKE CONCAT('%',@Find,'%')");
            db.AppendLine(@"  OR Ename LIKE CONCAT('%',@Find,'%')");
            db.AppendLine(@"  OR Ephone LIKE CONCAT('%',@Find,'%')");
            db.AppendLine(@"  OR Eaddress LIKE CONCAT('%',@Find,'%')");
            db.AppendLine(@"  OR Enote LIKE CONCAT('%',@Find,'%')");
            db.AppendLine(@"  OR SHid LIKE CONCAT('%',@Find,'%')");

            db.AddParameter("Find", model.TxtFind, MySqlDbType.VarChar);

            return db.ExecuteReader();
        }

        /// <summary>
        /// 删除员工
        /// </summary>
        /// <param name="db"></param>
        /// <param name="model"></param>
        public static int DelEmployess(DBManagerMySql db, PageEmployessViewModel model)
        {
            db.AppendLine(@"DELETE FROM T_Employess ");
            db.AppendLine(@"WHERE");
            db.AppendLine(@"    Eid = @Eid");

            db.AddParameter("Eid", model.SelectedEmployess.Eid, MySqlDbType.VarChar);

            return db.ExecuteNonQuery();
        }
    }
}
