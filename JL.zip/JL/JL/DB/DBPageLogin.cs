﻿using MySql.Data.MySqlClient;

namespace JL
{
    /// <summary>
    /// 登录画面
    /// </summary>
    public static class DBPageLogin
    {
        /// <summary>
        /// 验证用户名密码
        /// </summary>
        /// <param name="db"></param>
        /// <param name="model"></param>
        public static long CheckUserPass(DBManagerMySql db, PageLoginViewModel model)
        {
            db.AppendLine(@"SELECT count(1)");
            db.AppendLine(@"FROM user");
            db.AppendLine(@"WHERE user_name = @user_name");
            db.AppendLine(@"  AND user_password= @user_password");
            db.AppendLine(@"  AND delete_status= '1'");

            db.AddParameter("user_name", model.LoginUser, MySqlDbType.VarChar);
            db.AddParameter("user_password", model.LoginPassword, MySqlDbType.VarChar);

            return (long)db.ExecuteScalar();
        }
    }
}
