﻿using System.ComponentModel;

namespace JL
{
    public static class UMessage
    {
        public const string MsgTitle01 = "确认";
        public const string MsgTitle02 = "警告";
        public const string MsgTitle03 = "异常";

        public const string Msg01 = "请输入用户名或密码";
        public const string Msg02 = "用户名或密码不正确";
        public const string Msg03 = "异常信息发生，请联系开发人员！";

        public const string MsgDB01 = "数据插入成功！";
        public const string MsgDB02 = "数据删除成功！";
        public const string MsgDB03 = "数据更新成功！";
        public const string MsgDB04 = "数据插入失败！";
        public const string MsgDB05 = "数据删除失败！";
        public const string MsgDB06 = "数据更新失败！";
    }

    public static class ChildTitle
    {
        public const string EmpAdd = "员工(添加)";
        public const string EmpUpd = "员工(更新)";
    }

    /// <summary>
    /// 页面类型
    /// </summary>
    public enum PageType
    {
        [Description("菜单")] MENU = 0,
        [Description("订单")] SEST = 1,
        [Description("库存")] STOC = 2,
        [Description("商品")] GOOD = 3,
        [Description("登录")] LOGI = 4,
        [Description("员工")] EMPL = 5,
        [Description("员工(增)")] EMPADD = 6,
        [Description("员工(复)")] EMPCPY = 7,
        [Description("员工(改)")] EMPUPD = 8,
    }

    /// <summary>
    /// MenuList
    /// </summary>
    public enum MenuType
    {
        [Description("销售")] MENU0 = 0,
        [Description("进货")] MENU1 = 1,
        [Description("商品信息变更")] MENU2 = 2,
        [Description("添加商品")] MENU3 = 3,
        [Description("库存查询")] MENU4 = 4,
        [Description("店铺查询")] MENU5 = 5,
        [Description("员工检索")] EMPS = 6,
        [Description("员工变动")] EMPU = 7,
        [Description("工资查询")] MENU8 = 8,
        [Description("信息变更")] MENU9 = 9,
        [Description("信息变更")] MENU10 = 10,
    }

    /// <summary>
    /// 订单种类
    /// </summary>
    public enum OrderType
    {
        [Description("销售(出)")] SELOT = 0,
        [Description("销售(退)")] SELIN = 1,
        [Description("进货(退)")] STCOT = 2,
        [Description("进货(进)")] STCIN = 3,
    }
}
