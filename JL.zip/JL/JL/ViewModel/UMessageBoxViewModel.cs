﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace JL
{
    public class UMessageBoxViewModel:BaseViewModel
    {
        private UMessageBox mWin;

        #region 依赖属性

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 消息
        /// </summary>
        public string Message { get; set; }

        #endregion

        #region 命令

        /// <summary>
        /// 确认按钮
        /// </summary>
        public ICommand YesCommand { get; set; }

        /// <summary>
        /// 取消按钮
        /// </summary>
        public ICommand NoCommand { get; set; }

        #endregion

        #region 构造

        public UMessageBoxViewModel(UMessageBox win,string title,string message)
        {
            this.mWin = win;
            Title = title;
            Message = message;

            YesCommand = new RelayCommand(YesButton);
            NoCommand = new RelayCommand(NoButton);
        }

        #endregion

        #region 函数

        /// <summary>
        /// 确认按钮
        /// </summary>
        private void YesButton()
        {
            _win.Close();
        }

        /// <summary>
        /// 取消按钮
        /// </summary>
        private void NoButton()
        {
            _win.Close();
        }

        #endregion
    }
}
