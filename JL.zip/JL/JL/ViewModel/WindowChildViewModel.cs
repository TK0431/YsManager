﻿using System.Windows.Input;

namespace JL
{
    public class WindowChildViewModel:BaseViewModel
    {
        public WindowChild mWin;
        private LogicWindowChild _logic = new LogicWindowChild();

        #region 属性

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 父画面内容
        /// </summary>
        public BaseViewModel FatherPage { get; set; }

        #endregion

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="win">子窗口</param>
        /// <param name="type">子窗口类型</param>
        /// <param name="model">父窗口数据</param>
        public WindowChildViewModel(WindowChild win ,PageType type,BaseViewModel page)
        {
            this.mWin = win;
            FatherPage = page;

            // 设置标题
            _logic.Init(this, type);
        }

    }
}
