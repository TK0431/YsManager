﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace JL
{
    public class PageShellStockViewModel:BaseViewModel
    {
        private LogicPageShellStock _logic = new LogicPageShellStock();
        //public PageShellStock _page;

        public bool SelOut { get; set; }
        public bool SelIn { get; set; }
        public bool StcOut { get; set; }
        public bool StcIn { get; set; }

        public DateTime DateFrom{ get; set; } = DateTime.Now.AddDays(1 - DateTime.Now.Day);
        public DateTime DateTo { get; set; } = DateTime.Now;

        public ObservableCollection<OrderModel> OrderList { get; set; } = new ObservableCollection<OrderModel>();

        public ICommand BackCommand { get; set; }
        public ICommand SearchCommand { get; set; }

        public PageShellStockViewModel(PageShellStock page)
        {
            _page = page;

            BackCommand = new RelayTCommand<PageShellStockViewModel>(_logic.BackButton);
            SearchCommand = new RelayTCommand<PageShellStockViewModel>(_logic.BackButton);

            OrderModel model = new OrderModel() {
                OrderId = "ID001",
                OrderType = OrderType.SELIN,
                OrderTime = DateTime.Now,
                OrderGoods = "阿迪达斯",
                OrderNum = 100,
                OrderPrice = 56000,
                OrderBack = "2019/01/02前发货",
                OrderUser = "蒋"
            };
            OrderList.Add(model);
            OrderList.Add(model);
            OrderList.Add(model);
            OrderList.Add(model);
            OrderList.Add(model);
            OrderList.Add(model);
            OrderList.Add(model);
        }
    }
}
