﻿
using System.Windows.Input;

namespace JL
{
    public class PageEmployessSetViewModel:BaseViewModel
    {
        LogicPageUserSet _logic = new LogicPageUserSet();

        public PageEmployessViewModel fatherModel;

        #region

        /// <summary>
        /// 编号
        /// </summary>
        public string Eid { get; set; }
        public bool EidErr { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Ename { get; set; }
        public bool EnameErr { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Epass { get; set; }
        public bool EpassErr { get; set; }

        /// <summary>
        /// 店铺
        /// </summary>
        public string SHid { get; set; }
        public bool SHidErr { get; set; }

        /// <summary>
        /// 权限
        /// </summary>
        public string Elevel { get; set; }
        public bool ElevelErr { get; set; }

        /// <summary>
        /// 电话
        /// </summary>
        public string Ephone { get; set; }
        public bool EphoneErr { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Eaddress { get; set; }
        public bool EaddressErr { get; set; }

        /// <summary>
        /// 底薪
        /// </summary>
        public string Esalary { get; set; }
        public bool EsalaryErr { get; set; }

        /// <summary>
        /// 提成
        /// </summary>
        public string Eprices { get; set; }
        public bool EpricesErr { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Enote { get; set; }
        public bool EnoteErr { get; set; }

        #endregion

        #region 命令

        /// <summary>
        /// 确定按钮
        /// </summary>
        public ICommand OKCommand { get; set; }

        /// <summary>
        /// 取消按钮
        /// </summary>
        public ICommand CancelCommand { get; set; }

        #endregion

        public PageEmployessSetViewModel(PageUserSet page ,PageEmployessViewModel father)
        {
            this._page = page;
            this._typePage = father._typeTarget;
            fatherModel = father;

            // 确定按钮
            OKCommand = new RelayTCommand<PageEmployessSetViewModel>(_logic.OKButton);
            // 取消按钮
            CancelCommand = new RelayTCommand<PageEmployessSetViewModel>(_logic.CloseButton);

            _logic.Init(this);
        }
    }
}
