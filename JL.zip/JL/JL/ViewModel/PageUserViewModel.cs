﻿using System.Windows.Input;
using System.Collections.ObjectModel;

namespace JL
{
    public class PageEmployessViewModel : BaseViewModel
    {
        private LogicPageUser _logic = new LogicPageUser();

        #region 属性

        /// <summary>
        /// 查询内容
        /// </summary>
        public string TxtFind { get; set; } = "";

        /// <summary>
        /// 员工List
        /// </summary>
        public ObservableCollection<EmployessModel> EmployessList { get; set; } = new ObservableCollection<EmployessModel>();

        /// <summary>
        /// 选中员工
        /// </summary>
        public EmployessModel SelectedEmployess { get; set; }

        #endregion

        #region 命令

        /// <summary>
        /// 返回
        /// </summary>
        public ICommand BackCommand { get; set; }

        /// <summary>
        /// 检索
        /// </summary>
        public ICommand SearchCommand { get; set; }

        /// <summary>
        /// 添加
        /// </summary>
        public ICommand AddCommand { get; set; }

        /// <summary>
        /// 修改
        /// </summary>
        public ICommand UpdCommand { get; set; }

        /// <summary>
        /// 复制
        /// </summary>
        public ICommand CpyCommand { get; set; }

        /// <summary>
        /// 删除
        /// </summary>
        public ICommand DelCommand { get; set; }

        #endregion

        public PageEmployessViewModel() { }

        public PageEmployessViewModel(PageUser page)
        {
            this._page = page;

            // 返回
            BackCommand = new RelayTCommand<PageEmployessViewModel>(_logic.BackButton);
            // 检索
            SearchCommand = new RelayTCommand<PageEmployessViewModel>(_logic.SearchButton);
            // 添加
            AddCommand = new RelayTCommand<PageEmployessViewModel>(_logic.AddButton);
            // 修正
            UpdCommand = new RelayTCommand<PageEmployessViewModel>(_logic.UpdButton);
            // 复制
            CpyCommand = new RelayTCommand<PageEmployessViewModel>(_logic.CpyButton);
            // 删除
            DelCommand = new RelayTCommand<PageEmployessViewModel>(_logic.DelButton);

            // 初期检索
            _logic.SearchButton(this);
        }
    }
}
