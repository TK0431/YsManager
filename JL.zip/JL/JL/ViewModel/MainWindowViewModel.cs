﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace JL
{
    public class MainWindowViewModel:BaseViewModel
    {
        public LogicMainWindow _logic = new LogicMainWindow();

        #region 依赖属性

        /// <summary>
        /// Page List
        /// </summary>
        public List<Page> MyProperty { get; set; } = new List<Page>();

        #endregion

        #region 命令

        /// <summary>
        /// 最小窗口
        /// </summary>
        public ICommand MinCommand { get; set; }

        /// <summary>
        /// 最大化窗口
        /// </summary>
        public ICommand MaxCommand { get; set; }

        /// <summary>
        /// 关闭窗口
        /// </summary>
        public ICommand CloseCommand { get; set; }

        #endregion

        public PageType BusinessPage { get; set; } = PageType.LOGI;

        public MainWindowViewModel(MainWindow win)
        {
            this._win = win;
            _win.Width = 1200;
            _win.Height = 800;

            MinCommand = new RelayCommand(()=> _win.WindowState = WindowState.Minimized);
            MaxCommand = new RelayCommand(() => _win.WindowState ^= WindowState.Maximized);
            CloseCommand = new RelayCommand(() => _win.Close());
        }
    }
}
