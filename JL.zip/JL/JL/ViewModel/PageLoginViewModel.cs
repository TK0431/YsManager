﻿using System.Windows.Input;

namespace JL
{
    public class PageLoginViewModel:BaseViewModel
    {
        private LogicPageLogin _logic = new LogicPageLogin();

        #region 依赖属性

        /// <summary>
        /// 登录用户
        /// </summary>
        public string LoginUser { get; set; } = "S000";

        /// <summary>
        /// 登录密码
        /// </summary>
        public string LoginPassword { get; set; } = "12345";

        #endregion

        #region 命令

        /// <summary>
        /// 登录按钮
        /// </summary>
        public ICommand LoginCommand { get; set; }

        #endregion

        public PageLoginViewModel(PageLogin page)
        {
            this._page = page;

            LoginCommand = new RelayTCommand<PageLoginViewModel>(_logic.LoginButton);
        }
    }
}
