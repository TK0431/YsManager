﻿using System.Windows.Input;

namespace JL
{
    public class PageMenuViewModel:BaseViewModel
    {
        private LogicPageMenu _loigc = new LogicPageMenu();

        public ICommand AddTabItem { get; set; }

        public PageMenuViewModel()
        {
            AddTabItem = new RelayTCommand<MenuType>(_loigc.AddTabItem);
        }
    }
}
