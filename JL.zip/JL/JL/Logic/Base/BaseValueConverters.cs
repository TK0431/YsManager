﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace JL
{
    /// <summary>
    /// 允许直接XAML使用的基值转换器
    /// </summary>
    /// <typeparam name="T">Page的值</typeparam>
    public abstract class BaseValueConverters<T> : MarkupExtension, IValueConverter
        where T : class,new()
    {
        #region 私有成员

        /// <summary>
        /// 此值转换器的单个静态实例
        /// </summary>
        private static T mConverter = null;

        #endregion

        #region 标记扩展方法

        /// <summary>
        /// 提供值转换器的静态实例
        /// </summary>
        /// <param name="serviceProvider">服务提供者</param>
        /// <returns></returns>
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return mConverter ?? (mConverter = new T());
        }

        #endregion

        #region Value Converter Methods

        /// <summary>
        /// 转换另一种类型的方法
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public abstract object Convert(object value, Type targetType, object parameter, CultureInfo culture);

        /// <summary>
        /// 将值转换为源类型的方法
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public abstract object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture);

        #endregion
    }
}
