﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows.Data;

namespace JL
{
    /// <summary>
    /// 页面转换器
    /// </summary>
    public class PageValueConverter:BaseValueConverters<PageValueConverter>
    {
        public override object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            switch ((PageType)value)
            {
                case PageType.LOGI:
                    // 登录界面
                    return new PageLogin();
                case PageType.SEST:
                    // 销售进货
                    return new PageShellStock();
                case PageType.GOOD:
                    // 商品界面
                    return new PageGoods();
                case PageType.STOC:
                    // 库存界面
                    return new PageStock();
                default:
                    Debugger.Break();
                    return null;
            }
        }

        public override object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// 子页面转换器
    /// </summary>
    public class PageChildValueConverter : BaseValueConverters<PageChildValueConverter>
    {
        public override object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            switch (((BaseViewModel)value)._typeTarget)
            {
                case PageType.EMPADD:
                case PageType.EMPCPY:
                case PageType.EMPUPD:
                    // 用户增加，复制，修改
                    return new PageUserSet((PageEmployessViewModel)value);
                default:
                    Debugger.Break();
                    return null;
            }
        }

        public override object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// 通用单选框转换器
    /// </summary>
    public class EnumObjectConverter : BaseValueConverters<EnumObjectConverter>
    {
        public override object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value == null ? false : value.Equals(parameter);
        }

        public override object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null && value.Equals(true) ? parameter : Binding.DoNothing;
        }
    }
}
