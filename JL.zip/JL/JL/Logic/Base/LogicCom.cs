﻿using System.Text.RegularExpressions;

namespace JL
{
    public static class LogicCom
    {
        /// <summary>
        /// 检验电话号码
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public static bool PhoneCheck(string phone)
        {
            return Regex.IsMatch(phone, "^(0\\d{2,3}-?\\d{7,8}(-\\d{3,5}){0,1})|(((13[0-9])|(15([0-3]|[5-9]))|(18[0-9])|(17[0-9])|(14[0-9]))\\d{8})$");
        }

        /// <summary>
        /// 权限Check
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public static bool LevelCheck(string level)
        {
            if (int.TryParse(level, out int result))
                if (result >= 0 && result <= 9) return true;
                else return false;
            else
                return false;
        }

        /// <summary>
        /// 小数Check
        /// </summary>
        /// <param name="num">检验数字</param>
        /// <param name="decNum">小数位数</param>
        /// <param name="min">左范围(包含)</param>
        /// <param name="max">右范围(包含)</param>
        /// <returns></returns>
        public static bool DecimalCheck(string num, int decNum = 0, decimal min = decimal.MinValue, decimal max = decimal.MaxValue)
        {
            if (decimal.TryParse(num, out decimal result))
            {
                if ((decNum > 1) && (num.IndexOf(".") > 0) && ((num.Length - num.IndexOf(".") - 1) > decNum)) return false;

                if ((min > int.MinValue) && (result < min)) return false;

                if ((max < int.MaxValue) && (result > max)) return false;

                return true;
            }
            else return false;
        }
    }
}
