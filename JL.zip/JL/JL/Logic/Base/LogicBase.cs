﻿using System.Windows;
using System.Windows.Navigation;

namespace JL
{
    public class LogicBase
    {
        /// <summary>
        /// 返回
        /// </summary>
        /// <param name="model"></param>
        public void BackButton(BaseViewModel model)
        {
            
        }

        /// <summary>
        /// 关闭按钮
        /// </summary>
        /// <param name="model"></param>
        public void CloseButton(BaseViewModel model)
        {
            Window.GetWindow(model._page).Close();
        }
    }
}
