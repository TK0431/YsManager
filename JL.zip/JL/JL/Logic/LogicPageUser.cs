﻿using MySql.Data.MySqlClient;
using static JL.DBDataMySql;

namespace JL
{
    public class LogicPageUser:LogicBase
    {
        /// <summary>
        /// 检索按钮
        /// </summary>
        /// <param name="model"></param>
        public void SearchButton(PageEmployessViewModel model)
        {
            using (DBManagerMySql db = new DBManagerMySql())
            {
                // 模糊检索
                MySqlDataReader sdr = DBPageUser.SearchUser(db, model);

                model.EmployessList.Clear();
                while (sdr.Read())
                {
                    EmployessModel item = new EmployessModel() {
                        Eid = TOString(sdr["Eid"]),
                        Epass = TOString(sdr["Epass"]),
                        Elevel = TOInt(sdr["Elevel"]),
                        Ename = TOString(sdr["Ename"]),
                        Ephone = TOString(sdr["Ephone"]),
                        Eaddress = TOString(sdr["Eaddress"]),
                        Eprices = TODecimal(sdr["Eprices"]),
                        Esalary = TODecimal(sdr["Esalary"]),
                        SHid = TOString(sdr["SHid"]),
                        Enote = TOString(sdr["Enote"]),
                    };
                    model.EmployessList.Add(item);
                }
                sdr.Close();
            }
        }

        /// <summary>
        /// 添加按钮
        /// </summary>
        /// <param name="model"></param>
        public void AddButton(PageEmployessViewModel model)
        {
            WindowChild.Show(PageType.EMPADD, model);
            this.SearchButton(model);
        }

        /// <summary>
        /// 修正按钮
        /// </summary>
        /// <param name="model"></param>
        public void UpdButton(PageEmployessViewModel model)
        {
            WindowChild.Show(PageType.EMPUPD, model);
            this.SearchButton(model);
        }

        /// <summary>
        /// 复制按钮
        /// </summary>
        /// <param name="model"></param>
        public void CpyButton(PageEmployessViewModel model)
        {
            WindowChild.Show(PageType.EMPCPY, model);
            this.SearchButton(model);
        }

        /// <summary>
        /// 删除按钮
        /// </summary>
        /// <param name="model"></param>
        public void DelButton(PageEmployessViewModel model)
        {
            using (DBManagerMySql db = new DBManagerMySql())
            {
                if (DBPageUser.DelEmployess(db, model) > 0)
                {
                    UMessageBox.Show(UMessage.MsgTitle01, UMessage.MsgDB02);
                    this.SearchButton(model);
                }
            }
        }

    }
}
