﻿namespace JL
{
    public class LogicWindowChild
    {
        /// <summary>
        /// 设置标题
        /// </summary>
        /// <param name="model"></param>
        /// <param name="type"></param>
        public void Init(WindowChildViewModel model, PageType type)
        {
            switch (type)
            {
                // 员工(添加)
                case PageType.EMPADD:
                    model.Title = ChildTitle.EmpAdd;
                    model.mWin.Width = 470;
                    model.mWin.Height = 650;
                    model.FatherPage._typeTarget = PageType.EMPADD;
                    break;
                // 员工(复制)
                case PageType.EMPCPY:
                    model.Title = ChildTitle.EmpAdd;
                    model.mWin.Width = 470;
                    model.mWin.Height = 650;
                    model.FatherPage._typeTarget = PageType.EMPCPY;
                    break;
                // 员工(更新)
                case PageType.EMPUPD:
                    model.Title = ChildTitle.EmpUpd;
                    model.mWin.Width = 470;
                    model.mWin.Height = 650;
                    model.FatherPage._typeTarget = PageType.EMPUPD;
                    break;
                default:
                    return;
            }
        }
    }
}
