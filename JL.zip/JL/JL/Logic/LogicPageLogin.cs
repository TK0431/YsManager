﻿using System.Windows;
using System.Windows.Navigation;
using static JL.UMessage;

namespace JL
{
    public class LogicPageLogin
    {
        /// <summary>
        /// 验证用户名密码
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool CheckUserPass(PageLoginViewModel model)
        {
            using (DBManagerMySql db = new DBManagerMySql())
            {
                long result = DBPageLogin.CheckUserPass(db, model);
                if (result <= 0) return false;
            }
            return true;
        }

        /// <summary>
        /// 登录成功则转入下一个画面
        /// </summary>
        public void LoginButton(PageLoginViewModel model)
        {
            if (string.IsNullOrEmpty(model.LoginUser) || string.IsNullOrEmpty(model.LoginPassword))
            {
                UMessageBox.Show("警告", Msg01);
                return;
            }

            if (this.CheckUserPass(model))
            {
                //NavigationService nav = NavigationService.GetNavigationService(model._page);
                //PageMenu page = new PageMenu();
                //nav.Navigate(page);
                model._win.fm.Visibility = Visibility.Collapsed;
                model._win.tc.Visibility = Visibility.Visible;
                model._win.me.Visibility = Visibility.Visible;
            }
            else
            {
                UMessageBox.Show("警告", Msg02);
            }
        }
    }
}
