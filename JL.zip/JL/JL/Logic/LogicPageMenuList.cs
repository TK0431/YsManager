﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace JL
{
    public class LogicPageMenu
    {
        public void AddTabItem(MenuType type)
        {
            TabControl tc = ((MainWindow)Application.Current.MainWindow).tc;

            UTabItem item = new UTabItem();
            Frame frame = new Frame();

            switch (type)
            {
                case MenuType.EMPS:
                    item.Header = string.Format("员工检索");
                    frame.Source = new Uri("pack://application:,,,/Page/PageUser.xaml", UriKind.Absolute);
                    break;
                default:
                    return;
            }

            item.Content = frame;
            tc.Items.Add(item);
        }
    }
}
