﻿
namespace JL
{
    public class LogicPageUserSet : LogicBase
    {
        public void Init(PageEmployessSetViewModel model)
        {
            if (model._typePage == PageType.EMPUPD || model._typePage == PageType.EMPCPY)
            {
                if (model._typePage == PageType.EMPUPD)
                {
                    // 编号
                    model.Eid = model.fatherModel.SelectedEmployess.Eid;
                }
                // 姓名
                model.Ename = model.fatherModel.SelectedEmployess.Ename;
                // 密码
                model.Epass = model.fatherModel.SelectedEmployess.Epass;
                // 店铺
                model.SHid = model.fatherModel.SelectedEmployess.SHid;
                // 权限
                model.Elevel = model.fatherModel.SelectedEmployess.Elevel.ToString();
                // 电话
                model.Ephone = model.fatherModel.SelectedEmployess.Ephone.ToString();
                // 地址
                model.Eaddress = model.fatherModel.SelectedEmployess.Eaddress;
                // 底薪
                model.Eprices = model.fatherModel.SelectedEmployess.Eprices.ToString();
                // 提成
                model.Esalary = model.fatherModel.SelectedEmployess.Esalary.ToString();
                // 备注
                model.Enote = model.fatherModel.SelectedEmployess.Enote;
            }
        }

        /// <summary>
        /// 确认按钮
        /// </summary>
        /// <param name="model"></param>
        public void OKButton(PageEmployessSetViewModel model)
        {
            if (!ErrorCheck(model)) return;

            using (DBManagerMySql db = new DBManagerMySql())
            {
                int result;
                switch (model._typePage)
                {
                    case PageType.EMPADD:
                    case PageType.EMPCPY:
                        result = DBPageUserSet.AddEmployess(db, model);
                        if (result > 0) UMessageBox.Show(UMessage.Msg01, UMessage.MsgDB01);
                        break;
                    case PageType.EMPUPD:
                        result = DBPageUserSet.UpdEmployess(db, model);
                        if (result > 0) UMessageBox.Show(UMessage.Msg01, UMessage.MsgDB03);
                        break;
                    default:
                        UMessageBox.Show(UMessage.MsgTitle02, UMessage.Msg03);
                        return;
                }
            }
            this.CloseButton(model);
        }

        /// <summary>
        /// Check
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool ErrorCheck(PageEmployessSetViewModel model)
        {
            // 异常初始化
            ErrorInio(model);

            // 空判断
            if (string.IsNullOrEmpty(model.Eid)) model.EidErr = true;
            if (string.IsNullOrEmpty(model.Ename)) model.EnameErr = true;
            if (string.IsNullOrEmpty(model.Epass)) model.EpassErr = true;
            if (string.IsNullOrEmpty(model.Elevel)) model.ElevelErr = true;

            // 权限Check
            if (!LogicCom.LevelCheck(model.Elevel))
                model.ElevelErr = true;

            // 电话号码
            if (!string.IsNullOrEmpty(model.Ephone))
                if (!LogicCom.PhoneCheck(model.Ephone))
                    model.EphoneErr = true;

            // 底薪
            if (!string.IsNullOrEmpty(model.Esalary))
                if (!LogicCom.DecimalCheck(model.Esalary, 2, 0, (decimal)9999999.99))
                    model.EsalaryErr = true;

            // 提成
            if (!string.IsNullOrEmpty(model.Eprices))
                if (!LogicCom.DecimalCheck(model.Eprices, 2, 0, (decimal)0.99))
                    model.EpricesErr = true;

            if (model.EidErr || model.EnameErr || model.EpassErr || model.ElevelErr ||
                model.EphoneErr || model.EsalaryErr || model.EpricesErr)
                return false;
            return true;
        }

        /// <summary>
        /// 异常初始化
        /// </summary>
        /// <param name="model"></param>
        public void ErrorInio(PageEmployessSetViewModel model)
        {
            model.EidErr = false;
            model.ElevelErr = false;
            model.EnameErr = false;
            model.EpassErr = false;
            model.EphoneErr = false;
            model.EpricesErr = false;
            model.EsalaryErr = false;
            model.EaddressErr = false;
            model.EnoteErr = false;
        }
    }
}
