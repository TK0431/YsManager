﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;

namespace JL
{
    public class LogicMainWindow : LogicBase
    {
    }
}