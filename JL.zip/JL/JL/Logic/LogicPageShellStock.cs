﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Navigation;
using static JL.DBDataMySql;

namespace JL
{
    public class LogicPageShellStock
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        public void BackButton(PageShellStockViewModel model)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        public void SearchButton(PageShellStockViewModel model)
        {
            using (DBManagerMySql db = new DBManagerMySql())
            {
                MySqlDataReader sdr = DBPageShellStock.GetListInfo(db, model);
                model.OrderList.Clear();
                while (sdr.Read())
                {
                    OrderModel item = new OrderModel()
                    {
                        OrderId = TOString(sdr["OrderId"]),
                        OrderType = (OrderType)TOEnum(sdr["OrderType"],typeof(OrderType)),
                        OrderTime = TODateTime(sdr["OrderTime"]),
                        OrderGoods = TOString(sdr["OrderGoods"]),
                        OrderNum = TODecimal(sdr["OrderNum"]),
                        OrderPrice = TODecimal(sdr["OrderPrice"]),
                        OrderBack = TOString(sdr["OrderBack"]),
                        OrderUser = TOString(sdr["OrderUser"]),
                    };
                    model.OrderList.Add(item);
                }
                sdr.Close();
            }
        }
    }
}