﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace JL
{
    /// <summary>
    /// 公共附加属性
    /// </summary>
    public static class ComCtlAttachProperty
    {

        /// <summary>
        /// 聚焦边框色
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static Brush GetFocusBorderBrush(DependencyObject obj)
        {
            return (Brush)obj.GetValue(FocusBorderBrushProperty);
        }

        public static void SetFocusBorderBrush(DependencyObject obj, Brush value)
        {
            obj.SetValue(FocusBorderBrushProperty, value);
        }

        public static readonly DependencyProperty FocusBorderBrushProperty =
            DependencyProperty.RegisterAttached("FocusBorderBrush", typeof(Brush), typeof(ComCtlAttachProperty), new PropertyMetadata(null));


        /// <summary>
        /// 按下边框色
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static Brush GetPressBorderBrush(DependencyObject obj)
        {
            return (Brush)obj.GetValue(PressBorderBrushProperty);
        }

        public static void SetPressBorderBrush(DependencyObject obj, Brush value)
        {
            obj.SetValue(PressBorderBrushProperty, value);
        }

        public static readonly DependencyProperty PressBorderBrushProperty =
            DependencyProperty.RegisterAttached("PressBorderBrush", typeof(Brush), typeof(ComCtlAttachProperty), new PropertyMetadata(null));


        /// <summary>
        /// 移入控件边框色
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static Brush GetMouseOverBorderBrush(DependencyObject obj)
        {
            return (Brush)obj.GetValue(MouseOverBorderBrushProperty);
        }

        public static void SetMouseOverBorderBrush(DependencyObject obj, Brush value)
        {
            obj.SetValue(MouseOverBorderBrushProperty, value);
        }

        public static readonly DependencyProperty MouseOverBorderBrushProperty =
            DependencyProperty.RegisterAttached("MouseOverBorderBrush", typeof(Brush), typeof(ComCtlAttachProperty), new PropertyMetadata(null));



        /// <summary>
        /// 圆角
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static CornerRadius GetCornerRadius(DependencyObject obj)
        {
            return (CornerRadius)obj.GetValue(CornerRadiusProperty);
        }

        public static void SetCornerRadius(DependencyObject obj, CornerRadius value)
        {
            obj.SetValue(CornerRadiusProperty, value);
        }

        public static readonly DependencyProperty CornerRadiusProperty =
            DependencyProperty.RegisterAttached("CornerRadius", typeof(CornerRadius), typeof(ComCtlAttachProperty), new PropertyMetadata(null));


        /// <summary>
        /// 附加控件模板
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static ControlTemplate GetAttachContent(DependencyObject obj)
        {
            return (ControlTemplate)obj.GetValue(AttachContentProperty);
        }

        public static void SetAttachContent(DependencyObject obj, ControlTemplate value)
        {
            obj.SetValue(AttachContentProperty, value);
        }

        public static readonly DependencyProperty AttachContentProperty =
            DependencyProperty.RegisterAttached("AttachContent", typeof(ControlTemplate), typeof(ComCtlAttachProperty), new PropertyMetadata(null));


        /// <summary>
        /// 按钮被按下Flg
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool GetButtonOnFlg(DependencyObject obj)
        {
            return (bool)obj.GetValue(ButtonOnFlgProperty);
        }

        public static void SetButtonOnFlg(DependencyObject obj, bool value)
        {
            obj.SetValue(ButtonOnFlgProperty, value);
        }

        public static readonly DependencyProperty ButtonOnFlgProperty =
            DependencyProperty.RegisterAttached("ButtonOnFlg", typeof(bool), typeof(ComCtlAttachProperty), new PropertyMetadata(false));


        /// <summary>
        /// 异常Flg
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool GetErrFlg(DependencyObject obj)
        {
            return (bool)obj.GetValue(ErrFlgProperty);
        }

        public static void SetErrFlg(DependencyObject obj, bool value)
        {
            obj.SetValue(ErrFlgProperty, value);
        }

        public static readonly DependencyProperty ErrFlgProperty =
            DependencyProperty.RegisterAttached("ErrFlg", typeof(bool), typeof(ComCtlAttachProperty), new PropertyMetadata(false));

    }
}
