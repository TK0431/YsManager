﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace JL
{
    /// <summary>
    /// UTabItem.xaml 的交互逻辑
    /// </summary>
    public partial class UTabItem : TabItem
    {
        public UTabItem()
        {
            InitializeComponent();
        }

        #region 成员变量

        /// <summary>
        /// 父级TabControl
        /// </summary>
        private TabControl m_Parent;

        #endregion

        #region 方法

        /// <summary>
        /// loaded
        /// </summary>
        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
            //找到父级TabControl
            m_Parent = FindParentTabControl(this);

        }

        /// <summary>
        /// 关闭按钮
        /// </summary>
        private void btn_Close_Click(object sender, RoutedEventArgs e)
        {
            if (m_Parent == null) return;

            //移除自身
            m_Parent.Items.Remove(this);
        }

        /// <summary>
        /// 递归找父级TabControl
        /// </summary>
        /// <param name="reference">依赖对象</param>
        /// <returns>TabControl</returns>
        private TabControl FindParentTabControl(DependencyObject reference)
        {
            DependencyObject dObj = VisualTreeHelper.GetParent(reference);
            if (dObj == null)
                return null;
            if (dObj.GetType() == typeof(TabControl))
                return dObj as TabControl;
            else
                return FindParentTabControl(dObj);
        }

        #endregion
    }
}
