﻿namespace JL
{
    /// <summary>
    /// T_Employess员工信息
    /// </summary>
    public class EmployessModel
    {
        /// <summary>
        /// ID
        /// </summary>
        public string Eid { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Epass { get; set; }

        /// <summary>
        /// 权限
        /// </summary>
        public int Elevel { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Ename { get; set; }

        /// <summary>
        /// 电话
        /// </summary>
        public string Ephone { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Eaddress { get; set; }

        /// <summary>
        /// 提成
        /// </summary>
        public decimal Eprices { get; set; }

        /// <summary>
        /// 底薪
        /// </summary>
        public decimal Esalary { get; set; }

        /// <summary>
        /// 店铺
        /// </summary>
        public string SHid { get; set; }

        // <summary>
        /// 备注
        /// </summary>
        public string Enote { get; set; }
    }
}
