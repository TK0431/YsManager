﻿using System;

namespace JL
{
    public class OrderModel
    {
        public string OrderId { get; set; }

        public OrderType OrderType { get; set; }

        public DateTime OrderTime { get; set; }

        public string OrderGoods { get; set; }

        public decimal OrderPrice { get; set; }

        public decimal OrderNum { get; set; }

        public string OrderBack { get; set; }

        public string OrderUser { get; set; }
    }
}
