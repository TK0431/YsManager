﻿using System.Windows;

namespace JL
{
    /// <summary>
    /// WindowChild.xaml 的交互逻辑
    /// </summary>
    public partial class WindowChild : Window
    {
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="type">子窗口类型</param>
        /// <param name="page">父窗口数据</param>
        public WindowChild(PageType type, BaseViewModel page)
        {
            InitializeComponent();

            this.DataContext = new WindowChildViewModel(this, type, page);
        }

        /// <summary>
        /// 静态方法 模拟MESSAGEBOX.Show方法
        /// </summary>
        /// <param name="type">子窗口类型</param>
        /// <param name="page">父窗口数据</param>
        /// <returns></returns>
        public static bool? Show(PageType type, BaseViewModel page)
        {
            WindowChild child = new WindowChild(type, page)
            {
                Owner = App.Current.MainWindow
            };
            return child.ShowDialog();
        }
    }
}
